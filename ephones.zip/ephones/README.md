CS50-Final-Project
my name is mohmed tony ,i live in egypt
YourLists: A Shopping store and Todo List Web App
A CS50 Final Project
Made as a final project for the course CS50's Introduction to Computer Science, Your store helps users manage their shopping lists as well as todo lists
usage
If someone one day preferred to buy an iPhone, this site will give him all the necessary information about the product, whether the size or the RAM, as well as the price. This site also contains different colors
There is also customer service and information on the page
Also the languages used to build this project
css
html
javascript
also using xampp
this vedio
https://www.youtube.com/watch?v=ZWUrzzUtj0c&ab_channel=MohmedTony
# Foobar

Foobar is a Python library for dealing with word pluralization.

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install foobar.

```bash
pip install foobar
```

## Usage

```python
import foobar

# returns 'words'
foobar.pluralize('word')

# returns 'geese'
foobar.pluralize('goose')

# returns 'phenomenon'
foobar.singularize('phenomena')
```

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate.

## License
[MIT](https://choosealicense.com/licenses/mit/)